package package1;

public class RBI {
	static final float  dollarRate=72;
	
	public float readDollarRate()
	{
		return dollarRate;
	}
	
	

}

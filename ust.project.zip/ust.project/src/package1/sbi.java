package package1;


public class sbi extends RBI implements NB {


	public  void calculateFD() 
	{
		
		System.out.println("fd rate in testcase is 8%");
		
	}

	
	
}

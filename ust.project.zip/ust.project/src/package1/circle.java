package package1;

public class circle extends shape {
	void calculateArea() 
	{
		System.out.println("Area of circle");
	}

}

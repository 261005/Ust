package javaproject;

public class child1 extends mom implements dad,granddad {
	public static void main(String[]args) {
		System.out.println("child 's height is "+(dad.height+10)+"eye colour inherited from mom is "+eyecolour);
		int shoe;
		System.out.println("large feet from granddad "+ (shoeSize -1));
	}

}

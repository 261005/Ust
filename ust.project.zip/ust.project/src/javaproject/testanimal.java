package javaproject;

public class testanimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		mycat smiley = new mycat();
		
		smiley.height = 10;
		smiley.colour = "brown";
		smiley.makesound();
		
        dog chotu = new dog();
		
		chotu.height = 20;
		chotu.colour = "black";
		chotu.makesound();

	}

}

package javaproject;

public  class animal {

	
		// TODO Auto-generated method stub

	 int height = 10;
     String colour = "brown";
	public void makesound()
	{

}
	
}
      

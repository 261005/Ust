package package1;

 interface NB {
	 
	 void calculateFD();
	
	

}

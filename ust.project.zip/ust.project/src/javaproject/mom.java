package javaproject;

public class mom {
	 static String eyecolour="blue";

}

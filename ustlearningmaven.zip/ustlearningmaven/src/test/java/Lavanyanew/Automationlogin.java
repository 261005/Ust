package Lavanyanew;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import utils.openChromeBrowser;

public class Automationlogin {
	
static WebDriver driver;
	
	
	public static void main(String[] args) {
		
			  
			openChromeBrowser ob = new openChromeBrowser();
			
			driver = ob.openChrome();
			
			driver.get("https://www.ebay.com/");
			
			driver.findElement(By.id("userid")).sendKeys("Lavanya.burri123@gmail.com");
			driver.findElement(By.id("pass")).sendKeys("Lavanya@0107");
		
			driver.findElement(By.cssSelector("#sgnBt")).click();
			
			
			
				
		
			//Second way to check login status
			
			//check if logout link is present
			try {
				driver.findElement(By.partialLinkText("Sign out"));
			}
			catch(NoSuchElementException e)
			{
				System.out.println("Login Failed");
			}
			
		
	}

}
	
	

	    
		
		
	


		
		
		



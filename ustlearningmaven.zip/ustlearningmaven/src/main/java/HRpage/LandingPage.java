package HRpage;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

public class LandingPage {
	
	static WebDriver driver;
	boolean res;
	
	//constructor
	public   LandingPage(WebDriver  driver)
	{
		this.driver=driver;
	}

	
	//methods 
	
	By flashsuccess = By.xpath("//*[@class=\"flash success\"]");
	
	
	
	// method to check login success
	
	public boolean isLoginSccuess() {
	 try
	{
		 driver.findElement(flashsuccess);
		 res = true;
	}
 
	catch(NoSuchElementException e)
	{
		res = false;
	}
	 
	return res;
	
}
}

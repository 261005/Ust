package package1;

import static org.junit.Assert.*;

import org.junit.Test;

public class sbitest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

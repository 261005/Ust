package javaproject;

interface dad {
	
	public static final int height=166; 

}

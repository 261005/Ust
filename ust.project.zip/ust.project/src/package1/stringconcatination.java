package package1;

public class stringconcatination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1 ="abcd,def";
		String s2 ="lav 123";
		
		System.out.println(s1+s2);
		
		System.out.println(s2.length());
		
		String[] strlArray = s2.split(" ");
		
		for (int i=0;i <strlArray.length; i++)
		{
			System.out.println(strlArray[i]);
		}
		

	}

}

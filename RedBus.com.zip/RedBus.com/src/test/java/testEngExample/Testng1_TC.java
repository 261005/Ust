package testEngExample;

import org.testng.annotations.Test;

public class Testng1_TC {
  @Test
  public void a() {
	  System.out.println("a method was executing");
	  
  }
  @Test
  public void b() {
	  
	  System.out.println("b method was executing");
	  
  }
}

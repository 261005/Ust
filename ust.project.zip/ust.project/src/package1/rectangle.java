package package1;

public class rectangle extends shape{
	void calculateArea()
	{
		System.out.println("Area of rectangle");
	}

}

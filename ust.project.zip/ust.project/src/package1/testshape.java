package package1;

public class testshape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		circle circle1=new circle();
		circle1.calculateArea();
		
		rectangle rectangle1=new rectangle();
		rectangle1.calculateArea();
		

	}

}

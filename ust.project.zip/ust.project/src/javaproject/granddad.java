package javaproject;

public interface granddad {
     final int shoeSize = 10;
}

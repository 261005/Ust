package fileHandling;

import java.util.TreeSet;

public class ArraylistEample {

	public static void main(String[] args) {
		TreeSet <String> names = new TreeSet <String>();
		
		
		names.add ("Lavanya");
		names.add("Naveen");
		names.add("Chaithu");
		
		System.out.println(names);
				

	}

}

package testEngExample;

import org.testng.annotations.Test;

public class testEng3_TC {
  @Test(dependsOnMethods="d")
  public void c()
  {
	  System.out.println("c method starts executing");
	 
  }
  @Test
  public void d() {
	  System.out.println("d method starts executing");
  }
  
}

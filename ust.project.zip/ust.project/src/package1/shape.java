package package1;

abstract class shape {
	
	abstract void calculateArea();
	
	

}

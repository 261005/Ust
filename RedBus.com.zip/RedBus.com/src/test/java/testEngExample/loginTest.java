package testEngExample;

import org.testng.annotations.Test;

import junit.framework.Assert;

import org.testng.annotations.DataProvider;

public class loginTest {
	boolean res;
	
  @Test(dataProvider = "dp")
  public void login(String u, String p) {
	  
	  
	  System.out.println("username:"+u+ "password:"+p);
	  
	  res=u.equals("thomsmith") ? true:false;
	  Assert.assertEquals(true, res);
	  
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "Lavanya", "456789" },
      new Object[] { "thomsmith", "supersaverpassword!" },
    };
  }
}

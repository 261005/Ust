package package1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File myFile = new File("c://temp//ust.txt");

		
          System.out.println(myFile.exists());
          Scanner myScanner = new Scanner (myFile);
          
          
          while (myScanner.hasNextLine()) {
        	  String line = myScanner.nextLine();
        	  System.out.println(line);
          }
          
          
          
          
		

	}

}

package fileHandling;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeExample {

	public static void main(String[] args) {
		LocalDateTime now = LocalDateTime.now(); 
		System.out.println("Before Formating:"+now);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-mm-yyyy HH:mm:ss");
					String formatDateTime = now.format(format);
		System.out.println("After Formatting:" + formatDateTime);
		
		System.out.println(LocalTime.now().getHour());
		int curtime = LocalTime.now().getHour();
		 String greet;
		 
		 
		 if (curtime <= 12)
		 {
			 greet ="gud mng";
		 }
		 
		 else if (curtime >=12 && curtime<=16)
		 {
			 greet = "gud afternoon";
		 }
		 else if (curtime >=16 && curtime<=19)
		 {
			 greet = "gud eveng";
			 
		 }
		 
		 else 
		 {
			 greet = "gudnyt";
		 }
		 
		 
		 System.out.println(LocalTime.now().getHour()+" "+greet);
		 
		 
		 }
	
	
		 
		 
		 
			 
		
		
		
		
		
		
		

	}



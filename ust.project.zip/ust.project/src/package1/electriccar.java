package package1;

public class electriccar extends car {
	public electriccar(String c, int h) {
  super(c,h);
  //todo auto-generated constructor stub
	}
	public boolean autoSteer()
	{
		return true;
	}
	public boolean Start()
	{
		System.out.println("started by pushing a button");
		return true;
	}
}

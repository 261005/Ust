
package javaproject;
 
public class  dog extends animal{
	
	public void makesound() 
	{
		System.out.println("bowow" + height + "black");
	}	


}

package javaproject;

public class mycat extends animal {
	
	public void makesound() 
	{
		System.out.println("meow" + height + "brown");
	}

}

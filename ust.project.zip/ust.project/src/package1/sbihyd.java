package package1;

public class sbihyd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       sbi sbihyd = new sbi();
       sbihyd.calculateFD();
       float dr = sbihyd.readDollarRate();
       System.out.println(dr);
	}

}

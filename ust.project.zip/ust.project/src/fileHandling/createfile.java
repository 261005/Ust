package fileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class createfile {

	public static void main(String[] args) throws IOException {
		
		FileWriter myWriter = new FileWriter ("C://Users//Administrator//Desktop//ust1.txt");	
		
		 myWriter.write("Hello"+"\n\r");
		 
		 myWriter.append("Adding a new line");
		 myWriter.flush();
		 }
}
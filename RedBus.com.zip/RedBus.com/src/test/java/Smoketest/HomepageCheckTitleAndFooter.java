package Smoketest;

import static org.junit.Assert.*;


import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class HomepageCheckTitleAndFooter {
	
	
	static WebDriver driver;
	
	@BeforeClass
	 

	public static void OpenBrowser()
	
	
	{
		
		driver = new ChromeDriver();
		driver.get("https://www.redbus.com/");
		
	}
	
	
	
	
	
	

	@Test
	public void CheckTitle()
	{
		String expected_Title = "Book Bus Tickets Online with redBus!";
		System.out.println("Expected Title is:"+ expected_Title);
		String actual_Title = driver.getTitle();
		System.out.println("Actual Title is:"+ actual_Title);
		
		Assert.assertEquals( actual_Title, expected_Title);
		
		 
	}
	
	@Test
	
	public void CheckFooter()
	{
		
		//scroll down to make footer text visible
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//scroll down till the bottom  of the page
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		String expected_Footer ="2024 ibibogroup All rights reserved";
		String actual_Footer = driver.findElement(By.xpath("//*[@id=\"rh_footer rdc-login\"]/div[2]/div/div/div[2]/div[3]/span")).getText();
		 
		System.out.println("Actual footer is:" + actual_Footer);

		Assert.assertEquals(actual_Footer, expected_Footer); 
		
	}
	
	

}

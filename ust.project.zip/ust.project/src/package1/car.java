package package1;

public class car {
	
	//String colour;
	private String colour;
	private int height;
    //constructor is called keyword  is used
	 public car (String c,int h ) {
		 this.colour = c ;
		 this.height = h ;
	 }
	 
	 		
	public boolean start()
	{
		System.out.println("started");
		return true;
	}
	public boolean stop()
	{
		System.out.println("stopped");
		return true ;
	}
     public String getcolour()
     {
    	 return this.colour;
     }
      
}

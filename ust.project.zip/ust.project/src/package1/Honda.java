package package1;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class Honda {
	public static car honda;
	
	@BeforeClass
	public static void dofirst() {
	
	 honda = new electriccar ("Red",100);
	
	 //honda.colour="Red";
	 //honda.height=100;
	 
	 System.out.println("executing first");
	 
}
   @Test
    public void teststart() {
	   boolean started = honda.start();
	   Assert.assertEquals(true, started);
   }
    
   
   @Test
   public void testcolourofHonda() {
	   boolean result;
	   result = (honda.getcolour() == "Red") ? (result=true):(result=false);
     Assert.assertEquals(true,result);
   }
   }
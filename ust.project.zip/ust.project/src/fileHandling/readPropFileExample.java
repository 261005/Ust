package fileHandling;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;

public class readPropFileExample {

	public static void main(String[] args) throws IOException {
		Properties p = new Properties();
		FileInputStream fil = new FileInputStream("src//file1.properties");
		p.load(fil);
		
		for (Entry<Object, Object> e :p.entrySet())
			
		{
			System.out.println(e);
		
			
		}
		String myURL =p.getProperty("url");
		
		System.out.println(myURL);
		

	}

}

package fileHandling;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Map.Entry;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;


public class assessment {
	
	public static String expectedgreet;
	public static String actualgreet;
	public static String greet;
	@BeforeClass
	
	public static void readPropertyfile() throws IOException {
		Properties p = new Properties();
		FileInputStream fil = new FileInputStream("src//file1.properties");
		p.load(fil);
		
	
		expectedgreet =p.getProperty("Expectedgreeting");
		
		System.out.println("expectedresult:" + expectedgreet);
		

	}

  

	

	@Test
	public void currTime() {
		
		LocalDateTime now = LocalDateTime.now(); 
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-mm-yyyy HH:mm:ss");
					
		    String formatDateTime = now.format(format);
			System.out.println("Current Date & Time:" + formatDateTime);
			
			
			int curtime = LocalTime.now().getHour();
			 
			 
			 
			 if (curtime <= 12)
			 {
				 actualgreet ="gudmng";
			 }
			 
			 else if (curtime >=12 && curtime<=16)
			 {
				 actualgreet = "gudafternoon";
			 }
			 else if (curtime >=16 && curtime<=19)
			 {
				 actualgreet = "gudeveng";
				 
			 }
			 
			 else 
			 {
				actualgreet = "gudnyt";
			 }
			 
			 
			 System.out.println(LocalTime.now().getHour());
			 System.out.println("Actual Result:" + actualgreet);
			 
			 Assert.assertEquals(actualgreet, expectedgreet);
			 
			 }
		
		
	}

	

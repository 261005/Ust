package testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class parametertesteng {
	
  @Parameters({ "first-name" })
  @Test
  public void a(String fn) {
	  
	  
	  System.out.println("First name " +fn );
	  assert"Lavanya".equals(fn);
	  
	  
  }
  
  
  @Parameters({ "Secound-name" })
  @Test
  
  public void b(String sn ) {
	  
	  
	  System.out.println("Secound -name " +sn );
	  assert"Burri".equals(sn);
	   
	  
  }
}

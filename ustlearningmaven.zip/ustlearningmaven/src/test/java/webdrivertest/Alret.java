package webdrivertest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Alret {

	
		static WebDriver driver;
		  
		public static void main(String[] args)  {
			driver = new ChromeDriver();
			 
			// Put an Implicit wait, 
			 
			 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 
			 //launch the url,
			 
			 driver.get("file:///C:/Users/Administrator/Desktop/myalerts.html.html");
			 
			 
			//Click the click show confrim  button to activate the alert
			// driver.findElement(By.id("btnConfirm")).click();
			 //driver.switchTo().alert().accept();
			 
		
			 //Click will show the alret button 
			 //driver.findElement(By.id("btnalert")).click();
			 //driver.switchTo().alert().accept();
			 
			 //click will promt button
			 
			 driver.findElement(By.id("btnprompt")).click();
			 String Show_prmpt = driver.switchTo().alert().getText();
			 //Thread.sleep(1000);
			 
			driver.switchTo().alert().accept();
			 System.out.println(Show_prmpt);
			 
			  driver.switchTo().alert().sendKeys("Automation");
			 
			// String text_prmpt = driver.findElement(By.id("output")).getText();
			//System.out.println(text_prmpt);
			 
			 
			 

			 
			
			 
			 
			
		}

		
		}

	



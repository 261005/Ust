package testcases;

import org.testng.annotations.Test;

public class Testngclass2 {
  @Test
  public void d() 
  
  {
 	  
 	  System.out.println("Method d is running");
 	  
   }
   
   @Test
   
   public void e()
   
   {
 	  System.out.println("method e is running");
 	  
   }
   
   @Test
   
   public void f()
   {
 	  
 	  System.out.println("method f is running");
   }
}
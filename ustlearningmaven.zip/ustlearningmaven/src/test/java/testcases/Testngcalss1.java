package testcases;


import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class Testngcalss1 {
	
	@Ignore	
  @Test
 public void a() 
   {
	    System.out.println("Method a is running");
	   }
  
  @Test
  
  public void b()
  
  {
	  System.out.println("method b is running");
	  
  }
  
  @Test
  
  public void c()
  {
	  
	  System.out.println("method c is running");
  }
  
  
}


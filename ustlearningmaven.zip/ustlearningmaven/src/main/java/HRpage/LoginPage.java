package HRpage;


import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	static WebDriver driver;
	boolean res;
	
	//constructor
	public   LoginPage(WebDriver  driver)
	{
		this.driver=driver;
	}
	
	//element decleration
	
	By username = By.id("username");
	By password = By.id("password");
	By loginbtn = By.cssSelector("#login > button");
	By footer = By.partialLinkText("Selenium");
	
	
	//methods
	 
	public boolean chkTitle(String exp_Title)
	{
		String act_Title = driver.getTitle();
		res = (act_Title.equals(exp_Title))? true:false;
		return res;
	}
		
	public void fileusername(String s) 
	{
		driver.findElement(username).sendKeys(s);
	}

	
	public void filepassword(String p)
	{
		driver.findElement(password).sendKeys(p);
		
	}
	
	public void Clickloginbtn()
	{
		driver.findElement(loginbtn).click();
	}
	
	
	//method to check fullpage download 
	
	public boolean chkPageFooter()
	{
		try
		{
			driver.findElement(footer);
			 res = true;
		}
		 catch (NoSuchElementException e)
		
		{
			 res = false;
		}
		
		return res;
	}

	// method to check masked password or not 
	
	public boolean isPasswordMasked() 
	{
		String masked = driver.findElement(password).getAttribute("type");
		
	    res=masked.equals("password") ? true : false;
	    
	    return res;
	}
}


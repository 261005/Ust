package package1;

public class simpleadd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f1=10;
		int f2=20;
		
		int sum = f1 + f2;
		System.out.println(f1 + " + " + f2 + " = " + sum);
		

	}
      
}

package fileHandling;

import java.util.HashMap;
import java.util.TreeSet;

public class Arraylisthashmap {

	public static void main(String[] args) {
		
			HashMap <Integer,String> names = new HashMap <Integer,String>();
			
			
			names.put (1,"Lavanya");
			names.put(2,"Naveen");
			names.put(3,"Chaithu");
			
			System.out.println(names);
					

		}


	}



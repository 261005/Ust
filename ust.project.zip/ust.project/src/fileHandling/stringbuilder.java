package fileHandling;

public class stringbuilder {

	public static void main(String[] args) {
		StringBuilder str = new StringBuilder("Welcome to ust");
		System.out.println(str);
		
		str.append("Global");
		System.out.println(str);
		
		//str.delete(2, 5);
		//System.out.println(str);
		
	    str.insert(6, "hyderabad");
	    System.out.println(str);
	    
	    str.replace(7, 19, "hyd");
	    System.out.println(str);
	    
	    System.out.println(str.substring(5, 10));

	}

}

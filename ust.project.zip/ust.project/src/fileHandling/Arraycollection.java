package fileHandling;

import java.util.ArrayList;
import java.util.Collections;

public class Arraycollection {

	public static void main(String[] args) {
		ArrayList <String> animals = new ArrayList <String>();
		  animals.add("tiger");
		  animals.add("camel");
		  animals.add("lion");
		  animals.add("donkey");
		  
		  Collections.sort(animals);
		  System.out.println(animals);

	}

}

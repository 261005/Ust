package fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readfile2 {

	public static void main1(String[] args)  {
		private static Object myFile1;
		private Object userdeatils1;

		public static void main(String[] args) throws FileNotFoundException {
			
			try {
			
			File myFile1 = new File("C://Users//Administrator//Desktop//ust.txt");

			
	          System.out.println(myFile1.exists());
	          Scanner myScanner = new Scanner (myFile1);
	          
	    
	          while (myScanner.hasNextLine()) {
	        	  String line = myScanner.nextLine();
	        	  System.out.println(line);
	        	  
	        	 String[] userdetails1 =line.split(",");
	        	 
	      	for (int i=0;i < userdetails1.length; i++)
					{
						switch (i)
						{
						case 0:
						{
							System.out.println("username:"+ userdetails1[i]);
							break;
						}
						case 1:
						{
							System.out.println("password:"+ userdetails1[i]);
							break;
						}
							
						
						}
					}
	          
	          }
			}
						

			


